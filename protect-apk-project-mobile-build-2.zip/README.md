# Protect APK — Android + backend

Project includes:
- Android app (Java, Android Studio / Gradle)
- FastAPI backend for SHA-256, trusted-hash matching, and APK signing-certificate verification using Google's `apksigner`
- Docker deployment configuration

## Security model
A valid APK signature means the APK's signed content verifies against its embedded signing certificate; it does NOT prove the APK is benign. SHA-256 is only a meaningful integrity check when compared with a trusted hash obtained independently. This starter project uses `backend/trusted_hashes.json` as the trusted allowlist. Add hashes through a secure release process, not from untrusted uploads.

## 1. Backend local run
Requirements: Python 3.11+, Android SDK Build Tools containing `apksigner` (or set `APKSIGNER_PATH`).

```bash
cd backend
python -m venv .venv
# Windows: .venv\Scripts\activate
# macOS/Linux:
source .venv/bin/activate
pip install -r requirements.txt
# Set APKSIGNER_PATH to the full path of apksigner if it is not on PATH.
uvicorn app:app --host 0.0.0.0 --port 8000
```
API health: `GET /health`
Scan: `POST /scan` multipart field `file`.

For Android emulator, use `http://10.0.2.2:8000/` in the app. For a physical phone, use your computer's LAN IP and ensure both devices share a network. HTTP is permitted only for local development in this starter app.

## 2. Backend Docker deployment
Deploy `backend/` to a host that supports Docker. The included Dockerfile installs Android command-line tools and Build Tools, then starts FastAPI on port 8000. Put it behind HTTPS (for example, a reverse proxy or hosting provider TLS). Set `MAX_UPLOAD_MB` to a suitable limit. Do not expose a development server directly to the public internet.

The backend's `trusted_hashes.json` is intentionally empty. Add a trusted release hash like:
```json
{
  "0123456789abcdef0123456789abcdef0123456789abcdef0123456789abcdef": {
    "label": "My official release",
    "certificate_sha256": "OPTIONAL_CERTIFICATE_DIGEST_WITHOUT_COLONS"
  }
}
```
Use the actual 64-character SHA-256 of a release APK. If `certificate_sha256` is provided, the app signing certificate must match it too. Keep this file under release/admin control; do not add an unauthenticated endpoint that lets users register hashes.

## 3. Build Android app
1. Install Android Studio and Android SDK (compile SDK 35 recommended).
2. Open the `android/` folder in Android Studio.
3. Let Gradle sync.
4. In `android/app/src/main/java/com/protectapk/app/MainActivity.java`, change `API_BASE_URL`:
   - Emulator local backend: `http://10.0.2.2:8000/`
   - Physical device local backend: `http://YOUR_COMPUTER_LAN_IP:8000/`
   - Deployed backend: `https://your-domain.example/`
5. For release builds, use HTTPS and disable cleartext traffic. This demo permits cleartext HTTP for local testing only; switch it off before publishing.
6. Build > Build APK(s). Output is normally `android/app/build/outputs/apk/debug/app-debug.apk`.
7. For a signed release: Build > Generate Signed Bundle / APK > APK, create/choose a keystore, and protect the keystore/password.

## API response
`POST /scan` returns:
- `sha256`
- `trusted_hash` (`MATCH`, `NO_MATCH`, or `NOT_CONFIGURED`)
- `signature_verified` (true/false)
- `signer_certificates` (certificate SHA-256 digests reported by apksigner)
- `assessment` (`TRUSTED_INTEGRITY_AND_SIGNATURE`, `SIGNATURE_VALID_HASH_UNTRUSTED`, or `SIGNATURE_INVALID_OR_UNVERIFIED`)

## Important limitations
- This is a starter integrity/signature scanner, not a malware antivirus.
- Use HTTPS, authentication/rate limits, file-size limits, isolated workers, and monitoring for public production use.
- The APK is uploaded to the server for scanning. Do not upload confidential files unless you control the server.
- Certificate output is parsed from `apksigner verify --print-certs`; verify compatibility with the Android Build Tools version you deploy.
