import hashlib
import json
import os
import re
import shutil
import subprocess
import tempfile
from pathlib import Path
from typing import Any

from fastapi import FastAPI, File, HTTPException, UploadFile
from fastapi.middleware.cors import CORSMiddleware

APP_DIR = Path(__file__).resolve().parent
TRUSTED_FILE = APP_DIR / "trusted_hashes.json"
MAX_UPLOAD_MB = int(os.getenv("MAX_UPLOAD_MB", "150"))
APKSIGNER = os.getenv("APKSIGNER_PATH") or shutil.which("apksigner")

app = FastAPI(title="Protect APK API", version="1.0.0")
# Restrict CORS in production if a browser client is added. Android clients are not governed by browser CORS.
app.add_middleware(
    CORSMiddleware,
    allow_origins=os.getenv("CORS_ORIGINS", "").split(",") if os.getenv("CORS_ORIGINS") else [],
    allow_credentials=False,
    allow_methods=["GET", "POST"],
    allow_headers=["*"],
)

def load_trusted_hashes() -> dict[str, Any]:
    try:
        raw = json.loads(TRUSTED_FILE.read_text(encoding="utf-8"))
        if not isinstance(raw, dict):
            return {}
        return {str(k).lower(): v for k, v in raw.items() if re.fullmatch(r"[0-9a-fA-F]{64}", str(k))}
    except (OSError, json.JSONDecodeError):
        return {}

def run_signature_verification(path: str) -> dict[str, Any]:
    if not APKSIGNER:
        return {
            "verified": False,
            "certificates": [],
            "error": "apksigner is not installed or APKSIGNER_PATH is not configured",
        }
    try:
        proc = subprocess.run(
            [APKSIGNER, "verify", "--verbose", "--print-certs", path],
            capture_output=True, text=True, timeout=45, check=False,
        )
    except subprocess.TimeoutExpired:
        return {"verified": False, "certificates": [], "error": "Signature verification timed out"}
    output = (proc.stdout or "") + "\n" + (proc.stderr or "")
    certs = []
    # apksigner commonly prints: Signer #1 certificate SHA-256 digest: ...
    for line in output.splitlines():
        if "certificate SHA-256 digest:" in line:
            digest = line.split("certificate SHA-256 digest:", 1)[1].strip().replace(":", "").lower()
            if re.fullmatch(r"[0-9a-f]{64}", digest):
                certs.append(digest)
    return {
        "verified": proc.returncode == 0,
        "certificates": sorted(set(certs)),
        "error": None if proc.returncode == 0 else (output.strip()[-1500:] or "apksigner verification failed"),
    }

@app.get("/health")
def health():
    return {"ok": True, "service": "Protect APK API", "apksigner_available": bool(APKSIGNER)}

@app.post("/scan")
async def scan(file: UploadFile = File(...)):
    filename = file.filename or "upload.apk"
    if not filename.lower().endswith(".apk"):
        raise HTTPException(status_code=400, detail="Please upload an .apk file.")
    limit = MAX_UPLOAD_MB * 1024 * 1024
    temp_path = None
    digest = hashlib.sha256()
    total = 0
    try:
        with tempfile.NamedTemporaryFile(prefix="protect-", suffix=".apk", delete=False) as temp:
            temp_path = temp.name
            while True:
                chunk = await file.read(1024 * 1024)
                if not chunk:
                    break
                total += len(chunk)
                if total > limit:
                    raise HTTPException(status_code=413, detail=f"APK exceeds {MAX_UPLOAD_MB} MB limit.")
                digest.update(chunk)
                temp.write(chunk)
        if total == 0:
            raise HTTPException(status_code=400, detail="Uploaded file is empty.")
        sha256 = digest.hexdigest()
        trusted = load_trusted_hashes()
        trusted_entry = trusted.get(sha256)
        sig = run_signature_verification(temp_path)
        certs = sig["certificates"]
        cert_match = True
        expected_cert = None
        if isinstance(trusted_entry, dict):
            expected_cert = str(trusted_entry.get("certificate_sha256", "")).replace(":", "").lower() or None
            if expected_cert:
                cert_match = expected_cert in certs
        trusted_match = bool(trusted_entry) and sig["verified"] and cert_match
        if trusted_match:
            assessment = "TRUSTED_INTEGRITY_AND_SIGNATURE"
        elif sig["verified"]:
            assessment = "SIGNATURE_VALID_HASH_UNTRUSTED"
        else:
            assessment = "SIGNATURE_INVALID_OR_UNVERIFIED"
        return {
            "filename": Path(filename).name,
            "size_bytes": total,
            "sha256": sha256,
            "trusted_hash": "MATCH" if trusted_entry else ("NO_MATCH" if trusted else "NOT_CONFIGURED"),
            "trusted_label": trusted_entry.get("label") if isinstance(trusted_entry, dict) else None,
            "signature_verified": sig["verified"],
            "signer_certificates": certs,
            "expected_certificate_matched": cert_match if expected_cert else None,
            "assessment": assessment,
            "notes": [
                "A valid signature does not prove an APK is malware-free.",
                "Hash matching is meaningful only when the allowlist hash was obtained from a trusted release process.",
            ],
            "signature_error": sig["error"],
        }
    finally:
        await file.close()
        if temp_path:
            try:
                os.remove(temp_path)
            except OSError:
                pass
